# Receta ejemplo Docker Compose Odoo

En este proyecto os comparto una receta para desplegar Odoo + PostgreSQL + Nginx
En el canal de videos encontrareis los videos de como usarlo.

(https://praxyaformaplus.com/slides/odoo-academy-videos-17)

## Requisitos

* Tener instalado Docker y Docker Compose

## Como usar?

1. Navegar hasta el directorio donde se encuenta el fichero .yml
2. Ejecutar el comando: docker-compose up

## Comandos basicos
docker ps: Muestra los contenedores activos

docker ps -a: todos conetenedores Activos/ no activos

docker-compose up: ejecuta el fichero .yml y construye todos los contenedores / servicios declarados

... mas comandos en los videos demostrativos




